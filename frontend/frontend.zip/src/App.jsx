import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext.jsx';
import useAuth from './hooks/useAuth.js';

// Layouts y Páginas
import Layout from './components/Layout.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import CajaDiaria from './pages/CajaDiaria.jsx';
import CierreDetalle from './pages/CierreDetalle.jsx';
import CuentasCorrientes from './pages/CuentasCorrientes.jsx';
import ClienteDetalle from './pages/ClienteDetalle.jsx';
import Retiros from './pages/Retiros.jsx';
import GestionUsuarios from './pages/GestionUsuarios.jsx';

// ================================================================
// ARCHIVO: src/App.jsx (Corregido)
//
// DESCRIPCIÓN:
// Se añade una comprobación segura (optional chaining `?.`) en
// `RutaProtegida` para evitar el error "Cannot read properties of
// undefined (reading 'token')".
// ================================================================


// Componente para proteger rutas que requieren autenticación
const RutaProtegida = ({ children }) => {
  const { auth, cargando } = useAuth();
  if (cargando) return <div className="flex justify-center items-center h-screen bg-primario text-white">Cargando...</div>;
  
  // FIX: Se usa `auth?.token` en lugar de `auth.token`.
  // Esto comprueba si `auth` existe ANTES de intentar acceder a `token`,
  // previniendo el error si `auth` es temporalmente `undefined`.
  return auth?.token ? children : <Navigate to="/" />;
};

// Componente para proteger rutas de solo administrador
const RutaAdmin = ({ children }) => {
  const { auth } = useAuth();
  // Se añade también la comprobación segura por consistencia.
  return auth?.rol === 'administrador' ? children : <Navigate to="/dashboard" />;
};

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          {/* Rutas Públicas */}
          <Route path="/" element={<Login />} />

          {/* Rutas Privadas (dentro del Layout) */}
          <Route path="/" element={<RutaProtegida><Layout /></RutaProtegida>}>
            <Route path="dashboard" index element={<Dashboard />} />
            <Route path="caja-diaria" element={<CajaDiaria />} />
            <Route path="cierre/:id" element={<CierreDetalle />} />
            <Route path="cuentas-corrientes" element={<CuentasCorrientes />} />
            <Route path="cuentas-corrientes/:id" element={<ClienteDetalle />} />
            <Route path="adelantos" element={<Retiros />} />
            
            {/* RUTA NUEVA SOLO PARA ADMINS */}
            <Route path="usuarios" element={<RutaAdmin><GestionUsuarios /></RutaAdmin>} />
          </Route>
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
